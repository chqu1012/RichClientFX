package de.dc.emf.javafx.xtext.demo.contact.controls;

public class ContactTableView extends BaseContactTableView{
}
