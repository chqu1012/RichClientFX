package de.dc.emf.javafx.xtext.demo.contact.controls.cell;

public enum ContactType {
	Forename, FamilyName, Age, Gender, Address;
}
