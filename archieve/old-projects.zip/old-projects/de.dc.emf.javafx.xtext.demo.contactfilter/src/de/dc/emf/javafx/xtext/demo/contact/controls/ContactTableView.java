package de.dc.emf.javafx.xtext.demo.contact.controls;

import javafx.scene.layout.*;
public class ContactTableView extends BaseContactTableView {
}
