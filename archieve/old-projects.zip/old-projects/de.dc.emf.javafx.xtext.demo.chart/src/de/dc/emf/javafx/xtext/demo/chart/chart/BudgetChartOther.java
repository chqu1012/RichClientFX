	package de.dc.emf.javafx.xtext.demo.chart.chart;
	public class BudgetChartOther extends BaseBudgetChartOther {
	}
