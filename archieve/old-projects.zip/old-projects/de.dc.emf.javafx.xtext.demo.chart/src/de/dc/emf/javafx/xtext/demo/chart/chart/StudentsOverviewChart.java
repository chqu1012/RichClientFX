	package de.dc.emf.javafx.xtext.demo.chart.chart;
	public class StudentsOverviewChart extends BaseStudentsOverviewChart {
	}
