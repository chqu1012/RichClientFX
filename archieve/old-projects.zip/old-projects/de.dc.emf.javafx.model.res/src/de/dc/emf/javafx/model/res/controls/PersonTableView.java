package de.dc.emf.javafx.model.res.controls;

public class PersonTableView extends BasePersonTableView{

}
