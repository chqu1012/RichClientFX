package de.dc.emf.javafx.model.res.controls.cell;

public enum PersonType {
	Name, Age;
}
