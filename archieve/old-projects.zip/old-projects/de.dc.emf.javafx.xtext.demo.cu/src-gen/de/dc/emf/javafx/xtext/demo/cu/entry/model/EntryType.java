package de.dc.emf.javafx.xtext.demo.cu.entry.model;

@SuppressWarnings("all")
public enum EntryType {
  Id,
  
  Name,
  
  Timestamp;
}
