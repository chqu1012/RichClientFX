package de.dc.emf.javafx.xtext.demo.cu.model;

@SuppressWarnings("all")
public enum ContactType {
  Name,
  
  Age,
  
  Gender,
  
  Address;
}
