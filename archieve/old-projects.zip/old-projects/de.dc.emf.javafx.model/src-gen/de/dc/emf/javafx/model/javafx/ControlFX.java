/**
 */
package de.dc.emf.javafx.model.javafx;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Control FX</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.javafx.model.javafx.JavafxPackage#getControlFX()
 * @model abstract="true"
 * @generated
 */
public interface ControlFX extends NamedElement {
} // ControlFX
