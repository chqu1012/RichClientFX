/**
 */
package de.dc.emf.javafx.model.javafx.impl;

import de.dc.emf.javafx.model.javafx.BarChartFX;
import de.dc.emf.javafx.model.javafx.JavafxPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bar Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BarChartFXImpl extends ChartFXImpl implements BarChartFX {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BarChartFXImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return JavafxPackage.Literals.BAR_CHART_FX;
	}

} //BarChartFXImpl
