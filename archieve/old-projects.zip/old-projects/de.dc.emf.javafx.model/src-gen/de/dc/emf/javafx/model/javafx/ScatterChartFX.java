/**
 */
package de.dc.emf.javafx.model.javafx;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scatter Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.javafx.model.javafx.JavafxPackage#getScatterChartFX()
 * @model
 * @generated
 */
public interface ScatterChartFX extends ChartFX {
} // ScatterChartFX
