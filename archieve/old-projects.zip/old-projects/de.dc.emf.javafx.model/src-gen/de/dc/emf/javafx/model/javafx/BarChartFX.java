/**
 */
package de.dc.emf.javafx.model.javafx;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bar Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.javafx.model.javafx.JavafxPackage#getBarChartFX()
 * @model
 * @generated
 */
public interface BarChartFX extends ChartFX {
} // BarChartFX
