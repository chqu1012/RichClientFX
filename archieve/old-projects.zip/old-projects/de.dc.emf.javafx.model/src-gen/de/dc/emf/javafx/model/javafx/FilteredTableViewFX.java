/**
 */
package de.dc.emf.javafx.model.javafx;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Filtered Table View FX</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.javafx.model.javafx.JavafxPackage#getFilteredTableViewFX()
 * @model
 * @generated
 */
public interface FilteredTableViewFX extends ControlFX, FilteredElement, TableViewFX {
} // FilteredTableViewFX
