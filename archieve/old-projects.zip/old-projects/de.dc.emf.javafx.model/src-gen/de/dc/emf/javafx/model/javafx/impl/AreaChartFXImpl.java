/**
 */
package de.dc.emf.javafx.model.javafx.impl;

import de.dc.emf.javafx.model.javafx.AreaChartFX;
import de.dc.emf.javafx.model.javafx.JavafxPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Area Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AreaChartFXImpl extends ChartFXImpl implements AreaChartFX {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AreaChartFXImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return JavafxPackage.Literals.AREA_CHART_FX;
	}

} //AreaChartFXImpl
