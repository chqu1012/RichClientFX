/**
 */
package de.dc.emf.javafx.model.javafx;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Line Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.javafx.model.javafx.JavafxPackage#getLineChartFX()
 * @model
 * @generated
 */
public interface LineChartFX extends ChartFX {
} // LineChartFX
