/**
 */
package de.dc.emf.javafx.model.javafx;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Area Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.javafx.model.javafx.JavafxPackage#getAreaChartFX()
 * @model
 * @generated
 */
public interface AreaChartFX extends ChartFX {
} // AreaChartFX
