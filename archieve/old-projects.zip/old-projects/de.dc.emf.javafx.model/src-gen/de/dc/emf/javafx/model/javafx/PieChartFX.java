/**
 */
package de.dc.emf.javafx.model.javafx;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pie Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.emf.javafx.model.javafx.JavafxPackage#getPieChartFX()
 * @model
 * @generated
 */
public interface PieChartFX extends ChartFX {
} // PieChartFX
