/**
 */
package de.dc.emf.javafx.model.javafx.impl;

import de.dc.emf.javafx.model.javafx.BubbleChartFX;
import de.dc.emf.javafx.model.javafx.JavafxPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bubble Chart FX</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BubbleChartFXImpl extends ChartFXImpl implements BubbleChartFX {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BubbleChartFXImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return JavafxPackage.Literals.BUBBLE_CHART_FX;
	}

} //BubbleChartFXImpl
